﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : Humunoid {

	private int spinAttackDamage = 10;

	public override int Attack ()
	{
		//base.Attack ();
		return base.attackDamage + spinAttackDamage;
	}

}
