﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ListTimeBaby : MonoBehaviour {

	string playerOne = "JohnnyKiller25";
	string playerTwo = "BamBamBunnyLover18";
	string playerThree = "DevSlopes";
	string playerFour = "PonYLOver";

	string[] player;

	// Use this for initialization
	void Start () {

		//Debug.Log ("Welcome " + playerOne);

		player = new string[4];

		populateArray ();

		for (int i = 0; i < 4; i++) {
			print ("Player " + (i + 1) + " contains: " + player [i]);
		}


	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void populateArray(){

		player [0] = playerOne;
		player [1] = playerTwo;
		player [2] = playerThree;
		player [3] = playerFour;

	}
		
}
