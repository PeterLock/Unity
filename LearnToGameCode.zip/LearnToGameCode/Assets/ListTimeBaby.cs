﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ListTimeBaby : MonoBehaviour {

	public GameObject cubePrefab;

	GameObject[] cubes = new GameObject[5];

	// Use this for initialization
	void Start () {



	}
	
	// Update is called once per frame
	void Update () {
		
	}

		
}
