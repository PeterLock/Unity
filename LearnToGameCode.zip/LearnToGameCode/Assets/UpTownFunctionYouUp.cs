﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpTownFunctionYouUp : MonoBehaviour {


	int health = 100;
	int attackPower = 25;

	void Start(){
		Debug.Log ("Health at start: " + health);
	}

	public void Attack(){
		//health = health - attackPower;
		health -= attackPower;
		Debug.Log ("Health After Attack: " + health);
	}

	public void Heal(){
		health += GetRandomNumber ();
	}

	private int GetRandomNumber(){
		return Random.Range (2, 10);	
	}


}
