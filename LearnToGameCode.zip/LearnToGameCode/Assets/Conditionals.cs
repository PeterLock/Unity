﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Conditionals : MonoBehaviour {

	int playerOneTowersRemaining = 2;
	int playerTwoTowersRemaining = 2;

	bool playerOneMainTowerDestroyed = false;
	bool playerTwoMainTowerDestroyed = false;

	float timer = 200;


	// Use this for initialization
	void Start () {

		if(playerOneMainTowerDestroyed || playerTwoMainTowerDestroyed) {

			if(playerOneMainTowerDestroyed){
				Debug.Log("Player two wins");
			}else{
				Debug.Log("Player one wins");
			}
		} else if( timer <= 0 ){
		
			if (playerOneTowersRemaining < playerTwoTowersRemaining) {
				Debug.Log ("Player two wins");
			} else if (playerTwoTowersRemaining < playerOneTowersRemaining) {
				Debug.Log ("Player one wins");
			} else {
				Debug.Log ("The game was a draws");
			}
		}

		if (true == false || false != true && 1 == 1) {
		
			Debug.Log ("Did we get here");

		}


	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
